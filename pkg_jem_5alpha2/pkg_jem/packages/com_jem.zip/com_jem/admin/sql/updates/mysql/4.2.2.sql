-- update values
UPDATE `#__extensions` SET `element` = 'jem' WHERE `element` = 'jemquickicon'; 