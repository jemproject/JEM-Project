-- insert new config values
INSERT INTO `#__jem_config` (`keyname`, `value`, `access`) VALUES ('event_show_venue', '1', '0');
INSERT INTO `#__jem_config` (`keyname`, `value`, `access`) VALUES ('event_show_registration', '1', '0');
INSERT INTO `#__jem_config` (`keyname`, `value`, `access`) VALUES ('event_show_registration_counters', '1', '0');