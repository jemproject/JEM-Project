# JEM 5.0.0 alpha 2
released 2026-02-18

##  ALPHA – NOT FOR PRODUCTION SITES. 

Based on
- jemproject/JEM-Project
- Egnarts94/JEM-Project Responsive JEM

<!--
JEM 4.4.0 is compatible with Joomla 5 (and 4)

## To install
Download the installation package from https://www.joomlaeventmanager.net/download or install it in Joomla via the web installer.

## Documentation
https://www.joomlaeventmanager.net/documentation/basics

## Community Support
https://www.joomlaeventmanager.net/forum

## Translation:
https://app.transifex.com/jemproject/

## Changelog
https://www.joomlaeventmanager.net/project/changelog-jem-4

-->

## Errors
Please report errors here: [https://github.com/jemproject/JEM-Project/issues](https://github.com/jemproject/JEM-Project/issues).

