<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

class PlgQuickiconJem extends CMSPlugin
{
    // This file is intentionally left empty as we're using a service provider.
    // It's here to ensure Joomla recognizes this as a valid plugin.
}