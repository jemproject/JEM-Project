# README
The translations have to be made with cb language overrides: you add a file "override.php" into the language folder of your 
language in /components/com_comprofiler/plugin/language/YOURLANGUAGE

If you already use cb language overrides (means: there exists just a "override.php"), you have to insert manually the key words and translations.
If not, you will loose the just made overrides!
