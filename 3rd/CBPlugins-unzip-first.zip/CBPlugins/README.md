# README

## Community Builder JEM Plugin, v 2.8

The CB Plugins have to be installed __with the CB plugin installer – not with the Joomla installer!__
 
## Translations 
The translations have to be made with cb language overrides: you add a file "override.php" into the language folder of your 
language in /components/com_comprofiler/plugin/language/YOURLANGUAGE

If you already use CB language overrides (means: there exists just a "override.php"), you have to insert manually the key words and translations.
If not, you will loose the just made overrides!
