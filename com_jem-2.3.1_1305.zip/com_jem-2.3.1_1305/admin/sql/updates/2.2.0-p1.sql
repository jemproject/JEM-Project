-- insert new config values
INSERT IGNORE INTO `#__jem_config` (`keyname`, `value`)
	VALUES ('regallowcomments', '0'), ('regallowinvitation', '0');
