<?php
/**
 * @version 2.2.2
 * @package JEM
 * @copyright (C) 2013-2017 joomlaeventmanager.net
 * @copyright (C) 2005-2009 Christoph Lukes
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die ;

require_once dirname(__FILE__) . '/eventslist.php';

/**
 * Model-Calendar
 */
class JemModelMyplanning extends JemModelEventslist
{
	protected $_date = 0;

	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();

		$this->setdate(time());
		
		}

	public function setdate($date)
	{
		$this->_date = $date;
	}

	/**
	 * Method to auto-populate the model state.
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		# parent::populateState($ordering, $direction);
		$app          = JFactory::getApplication();
		$params       = $app->getParams();
		$task         = $app->input->get('task','','cmd');
		$top_category = $params->get('top_category', 0);
		$startdayonly = $params->get('show_only_start', false);

		# params
		$this->setState('params', $params);

		# publish state
		$this->_populatePublishState($task);

		###########
		## DATES ##
		###########

		#only select events within specified dates. (chosen month)
		$monthstart = mktime(0, 0, 1, strftime('%m', $this->_date), 1, strftime('%Y', $this->_date));
		$monthend   = mktime(0, 0, -1, strftime('%m', $this->_date)+1, 1, strftime('%Y', $this->_date));

		$filter_date_from = $this->_db->Quote(strftime('%Y-%m-%d', $monthstart));
		$filter_date_to   = $this->_db->Quote(strftime('%Y-%m-%d', $monthend));

		$where = ' DATEDIFF(IF (a.enddates IS NOT NULL, a.enddates, a.dates), '. $filter_date_from .') >= 0';
		$this->setState('filter.calendar_from',$where);

		$where = ' DATEDIFF(a.dates, '. $filter_date_to .') <= 0';
		$this->setState('filter.calendar_to',$where);

		##################
		## TOP-CATEGORY ##
		##################

		if ($top_category) {
			$children = JemCategories::getChilds($top_category);
			if (count($children)) {
				$where = 'rel.catid IN ('. implode(',', $children) .')';
				$this->setState('filter.category_top', $where);
			}
		}

		# set filter
		$this->setState('filter.calendar_multiday',true);
		$this->setState('filter.calendar_startdayonly',(bool)$startdayonly);
		$this->setState('filter.groupby',array('a.id'));
	}

	/**
	 * Method to get a list of events.
	 */
	public function getItems()
	{
		$items = parent::getItems();

		if ($items) {
			return $items;
		}

		return array();
	}

	/**
	 * @return JDatabaseQuery
	 */
	protected function getListQuery()
	{
		

		
		// Create a new query object.

		$app       = JFactory::getApplication();
		$task      = $app->input->getCmd('task', '');
		$itemid    = $app->input->getInt('id', 0) . ':' . $app->input->getInt('Itemid', 0);

		$params    = $app->getParams();
		$settings  = JemHelper::globalattribs();
		$user      = JemFactory::getUser();
		$levels    = $user->getAuthorisedViewLevels();

		# Query
		$db    = JFactory::getDBO();
		$query = $db->getQuery(true);

		# Event
		$query->select(
				$this->getState('list.select',
				'a.access,a.alias,a.attribs,a.checked_out,a.checked_out_time,a.contactid,a.created,a.created_by,a.created_by_alias,a.custom1,a.custom2,a.custom3,a.custom4,a.custom5,a.custom6,a.custom7,a.custom8,a.custom9,a.custom10,a.dates,a.datimage,a.enddates,a.endtimes,a.featured,' .
				'a.fulltext,a.hits,a.id,a.introtext,a.language,a.locid,a.maxplaces,a.metadata,a.meta_keywords,a.meta_description,a.modified,a.modified_by,a.published,a.registra,a.times,a.title,a.unregistra,a.waitinglist,DAYOFMONTH(a.dates) AS created_day, YEAR(a.dates) AS created_year, MONTH(a.dates) AS created_month,' .
				'a.recurrence_byday,a.recurrence_counter,a.recurrence_first_id,a.recurrence_limit,a.recurrence_limit_date,a.recurrence_number, a.recurrence_type,a.version'
			)
		);
		$query->from('#__jem_events as a');

		
		# Venue
		$query->select(array('l.alias AS l_alias','l.checked_out AS l_checked_out','l.checked_out_time AS l_checked_out_time','l.city','l.country','l.created AS l_created','l.created_by AS l_createdby'));
		$query->select(array('l.custom1 AS l_custom1','l.custom2 AS l_custom2','l.custom3 AS l_custom3','l.custom4 AS l_custom4','l.custom5 AS l_custom5','l.custom6 AS l_custom6','l.custom7 AS l_custom7','l.custom8 AS l_custom8','l.custom9 AS l_custom9','l.custom10 AS l_custom10'));
		$query->select(array('l.id AS l_id','l.latitude','l.locdescription','l.locimage','l.longitude','l.map','l.meta_description AS l_meta_description','l.meta_keywords AS l_meta_keywords','l.modified AS l_modified','l.modified_by AS l_modified_by','l.postalCode'));
		$query->select(array('l.publish_up AS l_publish_up','l.publish_down AS l_publish_down','l.published AS l_published','l.state','l.street','l.url','l.venue','l.version AS l_version'));
		$query->join('LEFT', '#__jem_venues AS l ON l.id = a.locid');

		
		# the rest
		$case_when_e  = ' CASE WHEN ';
		$case_when_e .= $query->charLength('a.alias','!=', '0');
		$case_when_e .= ' THEN ';
		$id_e = $query->castAsChar('a.id');
		$case_when_e .= $query->concatenate(array($id_e, 'a.alias'), ':');
		$case_when_e .= ' ELSE ';
		$case_when_e .= $id_e.' END as slug';

		$case_when_l  = ' CASE WHEN ';
		$case_when_l .= $query->charLength('l.alias', '!=', '0');
		$case_when_l .= ' THEN ';
		$id_l = $query->castAsChar('a.locid');
		$case_when_l .= $query->concatenate(array($id_l, 'l.alias'), ':');
		$case_when_l .= ' ELSE ';
		$case_when_l .= $id_l.' END as venueslug';

		$query->select(array($case_when_e, $case_when_l));

		# join over the category-tables
		$query->join('LEFT', '#__jem_cats_event_relations AS rel ON rel.itemid = a.id');
		$query->join('LEFT', '#__jem_categories AS c ON c.id = rel.catid');

		#############
		## FILTERS ##
		#############

		#####################
		## FILTER - EVENTS ##
		#####################

		# Filter by a single or group of events.
		$eventId = $this->getState('filter.event_id');

		if (is_numeric($eventId)) {
			$type = $this->getState('filter.event_id.include', true) ? '= ' : '<> ';
			$query->where('a.id '.$type.(int) $eventId);
		}
		elseif (is_array($eventId) && !empty($eventId)) {
			JArrayHelper::toInteger($eventId);
			$eventId = implode(',', $eventId);
			$type = $this->getState('filter.event_id.include', true) ? 'IN' : 'NOT IN';
			$query->where('a.id '.$type.' ('.$eventId.')');
		}

		###################
		## FILTER-ACCESS ##
		###################

		# Filter by access level - always.
		$query->where('a.access IN ('.implode(',', $levels).')');

		####################
		## FILTER-PUBLISH ##
		####################

		# Filter by published state.
		$where_pub = $this->_getPublishWhere();
		if (!empty($where_pub)) {
			$query->where('(' . implode(' OR ', $where_pub) . ')');
		} else {
			// something wrong - fallback to published events
			$query->where('a.published = 1');
		}
		#####################
		## FILTER-FEATURED ##
		#####################

		# Filter by featured flag.
		$featured = $this->getState('filter.featured');

		if (is_numeric($featured)) {
			$query->where('a.featured = ' . (int) $featured);
		}
		elseif (is_array($featured) && !empty($featured)) {
			JArrayHelper::toInteger($featured);
			$featured = implode(',', $featured);
			$query->where('a.featured IN ('.$featured.')');
		}

		#############################
		## FILTER - CALENDAR_DATES ##
		#############################
		$cal_from = $this->getState('filter.calendar_from');
		$cal_to   = $this->getState('filter.calendar_to');

		if ($cal_from) {
			$query->where($cal_from);
		}

		if ($cal_to) {
			$query->where($cal_to);
		}

		#############################
		## FILTER - OPEN_DATES     ##
		#############################
		$opendates = $this->getState('filter.opendates');

		switch ($opendates) {
		case 0: // don't show events without start date
		default:
			$query->where('a.dates IS NOT NULL');
			break;
		case 1: // show all events, with or without start date
			break;
		case 2: // show only events without startdate
			$query->where('a.dates IS NULL');
			break;
		}

		#####################
		### FILTER - BYCAT ##
		#####################

		$filter_catid = $this->getState('filter.filter_catid');
		if ($filter_catid) { // categorycal
			$query->where('c.id = '.(int)$filter_catid);
	   	}else {
			$cats = $this->getCategories('all');
			if (!empty($cats)) {
				$query->where('c.id  IN (' . implode(',', $cats) . ')');
			}
		}

		####################
		## FILTER - BYLOC ##
		####################
		$filter_locid = $this->getState('filter.filter_locid');
		if ($filter_locid) {
			$query->where('a.locid = '.(int)$filter_locid);
	    }

		####################
		## FILTER - VENUE ##
		####################

		$venueId = $this->getState('filter.venue_id');

		if (is_numeric($venueId)) {
			$type = $this->getState('filter.venue_id.include', true) ? '= ' : '<> ';
			$query->where('l.id '.$type.(int) $venueId);
		}
		elseif (is_array($venueId) && !empty($venueId)) {
			JArrayHelper::toInteger($venueId);
			$venueId = implode(',', $venueId);
			$type = $this->getState('filter.venue_id.include', true) ? 'IN' : 'NOT IN';
			$query->where('l.id '.$type.' ('.$venueId.')');
		}

		##########################
		## FILTER - VENUE STATE ##
		##########################

		$venueState = $this->getState('filter.venue_state');

		if (!empty($venueState)) {
			$venueState = explode(',', $venueState);

			$venueStateMode = $this->getState('filter.venue_state.mode', 0);
			switch ($venueStateMode) {
			case 0: # complete match: venue's state must be equal (ignoring upper/lower case) one of the strings given by filter
			default:
				array_walk($venueState, create_function('&$v,$k,$db','$v = $db->quote(trim($v));'), $db);
				$query->where('l.state IN ('.implode(',', $venueState).')');
				break;
			case 1: # contain: venue's state must contain one of the strings given by filter
				array_walk($venueState, create_function('&$v,$k,$db','$v = quotemeta($db->escape(trim($v), true));'), $db);
				$query->where('l.state REGEXP '.$db->quote(implode('|', $venueState)));
				break;
			}
		}

		###################
		## FILTER-SEARCH ##
		###################

		# define variables
		$filter = $this->getState('filter.filter_type');
		$search = $this->getState('filter.filter_search'); // not escaped

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = '.(int) substr($search, 3));
			} else {
				$search = $db->Quote('%'.$db->escape($search, true).'%', false); // escape once

				if ($search && $settings->get('global_show_filter')) {
					switch ($filter) {
						# case 4 is category, so it is omitted
						case 1:
							$query->where('a.title LIKE '.$search);
							break;
						case 2:
							$query->where('l.venue LIKE '.$search);
							break;
						case 3:
							$query->where('l.city LIKE '.$search);
							break;
						case 5:
							$query->where('l.state LIKE '.$search);
							break;
					}
				}
			}
		}

		# Group
		$group = $this->getState('filter.groupby');
		if ($group) {
			$query->group($group);
		}

		# ordering
		$orderby = $this->getState('filter.orderby');
		if ($orderby) {
			$query->order($orderby);
		}
         
         
          //  suite 
          

		# Get the WHERE  clause for the query
		$where   = $this->_buildWhere();
          
          
          
		// here we can extend the query of the Eventslist model
		//$query->select('DATEDIFF(a.enddates, a.dates) AS datesdiff, DAYOFMONTH(a.dates) AS start_day, YEAR(a.dates) AS start_year, MONTH(a.dates) AS start_month');
		$query->where( $where);

           
          
		return $query;
	}
	/**
	 * Build the where clause
	 *
	 * @access private
	 * @return string
	 */
	protected function _buildWhere()
	{
		$app      = JFactory::getApplication();
		$task     = $app->input->getCmd('task', '');
		$params   = $app->getParams();
		$settings = JemHelper::globalattribs();
		$user     = JemFactory::getUser();
		// Support Joomla access levels instead of single group id
		$levels   = $user->getAuthorisedViewLevels();

		$filter   = $app->getUserStateFromRequest('com_jem.myevents.filter', 'filter', 0, 'int');
		$search   = $app->getUserStateFromRequest('com_jem.myevents.filter_search', 'filter_search', '', 'string');
		$search   = $this->_db->escape(trim(JString::strtolower($search)));

		$where = array();
		// a.published traité auparavant
		
		$where[] = ' c.published = 1';
		// a.access traité auparavant
		$where[] = ' c.access IN (' . implode(',', $levels) . ')';

		// then if the user is the owner of the event
		$where[] = ' a.created_by = '.$this->_db->Quote($user->id);

		// get excluded categories
		$excluded_cats = trim($params->get('excluded_cats', ''));

		if ($excluded_cats != '') {
			$cats_excluded = explode(',', $excluded_cats);
			JArrayHelper::toInteger($cats_excluded);
			$where[] = '  c.id NOT IN (' . implode(',', $cats_excluded) . ')';
		}
		// === END Excluded categories add === //

		if ($settings->get('global_show_filter') && $search) {
			switch($filter) {
				case 1:
					$where[] = ' LOWER(a.title) LIKE \'%'.$search.'%\' ';
					break;
				case 2:
					$where[] = ' LOWER(l.venue) LIKE \'%'.$search.'%\' ';
					break;
				case 3:
					$where[] = ' LOWER(l.city) LIKE \'%'.$search.'%\' ';
					break;
				case 4:
					$where[] = ' LOWER(c.catname) LIKE \'%'.$search.'%\' ';
					break;
				case 5:
				default:
					$where[] = ' LOWER(l.state) LIKE \'%'.$search.'%\' ';
			}
		}

		$where2 = (count($where) ? '  ' . implode(' AND ', $where) : '');
				
		        
		return $where2;
	}
  
 

}
?>
