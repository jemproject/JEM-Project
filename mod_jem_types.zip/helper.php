<?php
/**
 * @package    JEM
 * @subpackage mod_jem_types
 * @copyright  (C) 2013-2026 joomlaeventmanager.net
 * @license    https://www.gnu.org/licenses/gpl-3.0 GNU/GPL
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Date\Date;

class ModJemTypesHelper
{
    /**
     * Summary mode: returns all published event types (entity=1) with event count.
     */
    public static function getTypeSummary($params)
    {
        $db     = Factory::getContainer()->get('DatabaseDriver');
        $app    = Factory::getApplication();
        $user   = JemFactory::getUser();
        $levels = $user->getAuthorisedViewLevels();
        $now    = (new Date('now', $app->get('offset')))->toSql();

        $query = $db->getQuery(true)
            ->select(array(
                't.id', 't.name', 't.alias', 't.icon', 't.color',
                'COUNT(DISTINCT a.id) AS event_count',
            ))
            ->from($db->quoteName('#__jem_types', 't'))
            ->join('LEFT',
                $db->quoteName('#__jem_events', 'a') . ' ON ' .
                $db->quoteName('a.type_id') . ' = ' . $db->quoteName('t.id') .
                ' AND ' . $db->quoteName('a.published') . ' = 1' .
                ' AND ' . $db->quoteName('a.access') . ' IN (' . implode(',', $levels) . ')' .
                ' AND (COALESCE(' . $db->quoteName('a.enddates') . ', ' . $db->quoteName('a.dates') . ') >= ' . $db->quote($now) . ')'
            )
            ->where($db->quoteName('t.published') . ' = 1')
            ->where($db->quoteName('t.entity') . ' = 1')
            ->group('t.id, t.name, t.alias, t.icon, t.color')
            ->order($db->quoteName('t.ordering') . ' ASC, ' . $db->quoteName('t.name') . ' ASC');

        if ($params->get('hide_empty', 0)) {
            $query->having('COUNT(DISTINCT a.id) > 0');
        }

        $db->setQuery($query);
        return $db->loadObjectList();
    }

    /**
     * Top-N mode: for each published type, returns the next N upcoming events.
     */
    public static function getTopNByType($params)
    {
        $db     = Factory::getContainer()->get('DatabaseDriver');
        $app    = Factory::getApplication();
        $user   = JemFactory::getUser();
        $levels = $user->getAuthorisedViewLevels();
        $now    = (new Date('now', $app->get('offset')))->toSql();
        $n      = max(1, (int) $params->get('top_n', 3));

        // Load all active types
        $typeQuery = $db->getQuery(true)
            ->select(array('id', 'name', 'alias', 'icon', 'color'))
            ->from($db->quoteName('#__jem_types'))
            ->where($db->quoteName('published') . ' = 1')
            ->where($db->quoteName('entity') . ' = 1')
            ->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('name') . ' ASC');

        $db->setQuery($typeQuery);
        $types = $db->loadObjectList();

        if (empty($types)) {
            return array();
        }

        $result = array();

        foreach ($types as $type) {
            // CASE slug
            $caseSlug = 'CASE WHEN ' . $db->quoteName('a.alias') . ' != \'\' THEN CONCAT(' .
                $db->quoteName('a.id') . ', \':\', ' . $db->quoteName('a.alias') . ') ELSE ' .
                $db->quoteName('a.id') . ' END';

            $eventQuery = $db->getQuery(true)
                ->select(array(
                    'a.id', 'a.title', 'a.alias', 'a.dates', 'a.times', 'a.enddates', 'a.endtimes',
                    '(' . $caseSlug . ') AS slug',
                ))
                ->from($db->quoteName('#__jem_events', 'a'))
                ->where($db->quoteName('a.type_id') . ' = ' . (int) $type->id)
                ->where($db->quoteName('a.published') . ' = 1')
                ->where($db->quoteName('a.access') . ' IN (' . implode(',', $levels) . ')')
                ->where('COALESCE(' . $db->quoteName('a.enddates') . ', ' . $db->quoteName('a.dates') . ') >= ' . $db->quote($now))
                ->order($db->quoteName('a.dates') . ' ASC')
                ->setLimit($n);

            $db->setQuery($eventQuery);
            $events = $db->loadObjectList();

            if (!empty($events) || !$params->get('hide_empty', 0)) {
                $type->events = $events;
                $result[]     = $type;
            }
        }

        return $result;
    }
}
