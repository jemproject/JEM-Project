ALTER TABLE `#__jem_settings`
	ADD `datemode` tinyint(4) NOT NULL DEFAULT '1' AFTER `datewidth`;