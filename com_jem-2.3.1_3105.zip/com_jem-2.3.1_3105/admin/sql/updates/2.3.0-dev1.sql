-- insert new config values
INSERT IGNORE INTO `#__jem_config` (`keyname`, `value`)
	VALUES ('layoutstyle', '1'), ('useiconfont', '0');
