ALTER TABLE `#__jem_settings`
	ADD css varchar(5120) NOT NULL DEFAULT '';