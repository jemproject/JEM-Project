ALTER TABLE `#__jem_venues`
	ADD custom1 varchar(200) NOT NULL DEFAULT '',
	ADD custom2 varchar(200) NOT NULL DEFAULT '',
	ADD custom3 varchar(100) NOT NULL DEFAULT '',
	ADD custom4 varchar(100) NOT NULL DEFAULT '',
	ADD custom5 varchar(100) NOT NULL DEFAULT '',
	ADD custom6 varchar(100) NOT NULL DEFAULT '',
	ADD custom7 varchar(100) NOT NULL DEFAULT '',
	ADD custom8 varchar(100) NOT NULL DEFAULT '',
	ADD custom9 varchar(100) NOT NULL DEFAULT '',
	ADD custom10 varchar(100) NOT NULL DEFAULT '';
