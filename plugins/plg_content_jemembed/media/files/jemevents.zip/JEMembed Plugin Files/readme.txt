Files to embed public JEM events in an external website
=======================================================

1. Upload jemevents.php and jemevents.js to the external website. The example
   HTML file is optional.

2. Edit the configuration section in jemevents.php:
   - Set SOURCE_DOMAIN to the HTTPS URL of the Joomla website running JEM.
   - Set SECURITY_TOKEN to one long random token configured in the JEM Embed
     plugin on that Joomla website.
   - Select the event filters, maximum page size (up to 100) and start offset.

   The token remains in the server-side PHP proxy. It is sent to Joomla in the
   Authorization Bearer header and must never be added to a browser URL or to
   client-side JavaScript.

   Keep the configuration names supplied in jemevents.php. The proxy translates
   them to the public JEM endpoint parameters and resolves relative event links
   against the trusted SOURCE_DOMAIN value.

   The featured option accepts on (all events), off (non-featured events) and
   only (featured events). The no_events_msg value is displayed as plain text
   when the feed contains no matching events.

3. Include the JavaScript file before the closing </body> tag:
   <script src="/jemevents.js"></script>

4. Add the event container where the events should appear:
   <div id="feed-container"></div>

The proxy verifies HTTPS, does not follow redirects while carrying credentials,
caches successful JSON responses briefly and shows only a generic public error.
