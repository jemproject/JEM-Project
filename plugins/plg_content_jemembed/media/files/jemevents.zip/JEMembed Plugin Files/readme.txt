Files to embed JEM events in external website:

1) Upload files to your web server Upload the files jemevents.php and jemevents.js to the web space of the external website. Note: The jemevents-example.html file is optional and for reference only.

2) Configure settings Open the jemevents.php file and fill in the configuration section according to your needs.

3) Include the JavaScript file On the webpage where you want to display the events, include the following line just before the closing </body> tag: <script src="/jemevents.js"></script>

4) Add the container for the events In the location on the page where the events should appear, add the following HTML element: <div id="jemevents-container"></div>
