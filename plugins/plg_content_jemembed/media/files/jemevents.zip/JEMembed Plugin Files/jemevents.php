<?php
declare(strict_types=1);

// Security Headers
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=300'); // Cache for 5 minutes
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'self'");
header("Referrer-Policy: strict-origin-when-cross-origin");

// ##########################################
// Configuration - EDIT BELOW
// ##########################################

// URL of the Joomla source website with the JEM events
const SOURCE_DOMAIN = 'https://www.example.com/';  // Include https:// and trailing slash!

// API token, set in the jemembed plugin settings of the Joomla source website
const SECURITY_TOKEN = 'SECURITY_TOKEN'; 

// Cache settings
const CACHE_ENABLED = true;       // Set to false to disable caching
const CACHE_TTL = 300;            // Cache lifetime in seconds (5 minutes)

// Parameters to define which events are loaded
$config = [
    'type' => 'unfinished', // today|unfinished|ongoing|upcoming|archived|newest|open|all
    'show_featured' => 'on', // on = all, off = non-featured, only = featured
    'title' => 'link', // on|link|off
    'cut_title' => 100, // a positive number
    'show_date' => 'on', // on|link|off
    'date_format' => '', // 
    'show_time' => 'on', // on|off
    'time_format' => '', // 
    'show_enddatetime' => 'on', // on|off
    'catids' => '', // comma separated category ids
    'show_category' => 'on', // on|link|off
    'venueids' => '', // comma separated venue ids
    'show_venue' => 'on', // on|link|off
    'max_events' => 100, // 1..100
    'start' => 0, // 0..10000, use meta.next_start for pagination
    'no_events_msg' => 'No events found.' // plain text, up to 200 characters
];

// ############################################
// END Configuration - DO NOT EDIT BELOW
// ############################################

final class JemEventsFetcher
{
    private const URL_BASE_PATH = 'index.php?option=com_ajax&plugin=jemembed&group=content&format=json';
    private const DEFAULT_USER_AGENT = 'JemEventsProxy/1.1 (+https://www.joomlaeventmanager.net)';
    private const CURL_CONNECT_TIMEOUT = 5;
    private const CURL_TIMEOUT = 10;
    private const QUERY_PARAMETER_MAP = [
        'type' => 'type',
        'show_featured' => 'featured',
        'title' => 'title',
        'cut_title' => 'cuttitle',
        'show_date' => 'date',
        'date_format' => 'dateformat',
        'show_time' => 'time',
        'time_format' => 'timeformat',
        'show_enddatetime' => 'enddatetime',
        'catids' => 'catids',
        'show_category' => 'category',
        'venueids' => 'venueids',
        'show_venue' => 'venue',
        'max_events' => 'max',
        'start' => 'start',
        'no_events_msg' => 'noeventsmsg',
    ];

    public function __construct(
        private string $sourceDomain,
        private string $token,
        private array $config,
        private bool $cacheEnabled = true,
        private int $cacheTtl = 300
    ) {
        $this->validateDomain($sourceDomain);
        $this->validateToken($token);
        $this->sourceDomain = rtrim($sourceDomain, '/') . '/';
    }

    public function fetchEvents(): void
    {
        $feedUrl = $this->buildFeedUrl();
        $cacheKey = hash('sha256', $feedUrl . "\0" . $this->token);

        // Try to get from cache first
        if ($this->cacheEnabled) {
            $cachedResponse = $this->getCachedResponse($cacheKey);
            if ($cachedResponse !== null) {
                echo $cachedResponse;
                return;
            }
        }
        
        // No cached data, fetch from remote
        $ch = $this->initCurl($feedUrl);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        $this->handleResponse($response, $httpCode, $cacheKey, $ch);
        curl_close($ch);
    }

    /**
     * Build the source URL using the public endpoint parameter names.
     *
     * @return string
     */
    private function buildFeedUrl(): string
    {
        $queryParameters = [];

        foreach (self::QUERY_PARAMETER_MAP as $configName => $requestName) {
            if (array_key_exists($configName, $this->config)) {
                $queryParameters[$requestName] = $this->config[$configName];
            }
        }

        return $this->sourceDomain . self::URL_BASE_PATH . '&' . 
            http_build_query($queryParameters, '', '&', PHP_QUERY_RFC3986);
    }

    private function initCurl(string $url): CurlHandle
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FAILONERROR => false,
            CURLOPT_USERAGENT => self::DEFAULT_USER_AGENT,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => self::CURL_CONNECT_TIMEOUT,
            CURLOPT_TIMEOUT => self::CURL_TIMEOUT,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Authorization: Bearer ' . $this->token,
            ]
        ]);
        return $ch;
    }

    private function handleResponse($response, int $httpCode, string $cacheKey, CurlHandle $ch): void
    {
        if (curl_errno($ch)) {
            $this->outputError('Proxy error: ' . curl_error($ch));
            return;
        }

        if (!is_string($response) || $httpCode < 200 || $httpCode >= 300) {
            $this->outputError("Unexpected source response: HTTP $httpCode");
            return;
        }

        $this->validateAndProcessJson($response, $cacheKey);
    }

    /**
     * Validate, normalise and return a successful JEM response.
     *
     * @param string $response Source response body.
     * @param string $cacheKey Opaque cache identifier.
     *
     * @return void
     */
    private function validateAndProcessJson(string $response, string $cacheKey): void
    {
        try {
            $payload = json_decode($response, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            $this->outputError('Invalid JSON: ' . $exception->getMessage());
            return;
        }

        if (!is_array($payload)
            || ($payload['success'] ?? false) !== true
            || !isset($payload['data'][0])
            || !is_array($payload['data'][0])
            || ($payload['data'][0]['success'] ?? false) !== true
            || !isset($payload['data'][0]['data'])
            || !is_array($payload['data'][0]['data'])) {
            $this->outputError('Unexpected JEM response structure');
            return;
        }

        $this->normaliseSourceUrls($payload);

        try {
            $response = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            $this->outputError('Could not encode the JEM response: ' . $exception->getMessage());
            return;
        }

        // Cache valid response if caching is enabled
        if ($this->cacheEnabled) {
            $this->setCachedResponse($cacheKey, $response);
        }

        echo $response;
    }

    /**
     * Resolve relative event links against the configured Joomla source.
     *
     * @param array $payload Decoded JEM response.
     *
     * @return void
     */
    private function normaliseSourceUrls(array &$payload): void
    {
        foreach ($payload as $name => &$value) {
            if (is_array($value)) {
                $this->normaliseSourceUrls($value);
            } elseif (is_string($value) && in_array($name, ['url', 'date_url'], true)) {
                $value = $this->makeSourceUrl($value);
            }
        }

        unset($value);
    }

    /**
     * Convert one safe relative link into an absolute source URL.
     *
     * @param string $url URL returned by the JEM endpoint.
     *
     * @return string
     */
    private function makeSourceUrl(string $url): string
    {
        $url = trim($url);

        if ($url === '' || $url === '#') {
            return $url;
        }

        $parts = parse_url($url);

        if ($parts === false) {
            return '#';
        }

        if (isset($parts['scheme'])) {
            return in_array(strtolower((string) $parts['scheme']), ['http', 'https'], true) ? $url : '#';
        }

        if (str_starts_with($url, '//')) {
            return '#';
        }

        if (str_starts_with($url, '/')) {
            $source = parse_url($this->sourceDomain);
            $authority = $source['scheme'] . '://' . $source['host'];

            if (isset($source['port'])) {
                $authority .= ':' . (int) $source['port'];
            }

            return $authority . $url;
        }

        return $this->sourceDomain . ltrim($url, '/');
    }

    private function validateDomain(string $domain): void
    {
        $parts = parse_url($domain);

        if (!filter_var($domain, FILTER_VALIDATE_URL) || !is_array($parts) || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            $this->outputError('Invalid source domain format');
            exit;
        }

        if (parse_url($domain, PHP_URL_SCHEME) !== 'https') {
            $this->outputError('Source domain must use HTTPS');
            exit;
        }
    }

    private function validateToken(string $token): void
    {
        if ($token === '' || strlen($token) > 512 || preg_match('/[\x00-\x20\x7f]/', $token)) {
            $this->outputError('Invalid API token configuration');
            exit;
        }
    }

    private function getCachedResponse(string $cacheKey): ?string
    {
        if (function_exists('apcu_exists') && apcu_exists($cacheKey)) {
            return apcu_fetch($cacheKey);
        }
        return null;
    }

    private function setCachedResponse(string $cacheKey, string $response): void
    {
        if (function_exists('apcu_store')) {
            apcu_store($cacheKey, $response, $this->cacheTtl);
        }
    }

    private function outputError(string $message): void
    {
        http_response_code(502);
        echo json_encode(['error' => 'Service unavailable']);
        $this->logError($message);
    }

    private function logError(string $message): void
    {
        error_log('JemEventsFetcher error: ' . $message);
    }
}

try {
    $fetcher = new JemEventsFetcher(
        SOURCE_DOMAIN, 
        SECURITY_TOKEN, 
        $config,
        CACHE_ENABLED,
        CACHE_TTL
    );
    $fetcher->fetchEvents();
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Service unavailable']);
    // Optional: Log the actual error for debugging
    // error_log("JemEventsFetcher critical error: " . $e->getMessage());
    exit;
}
